package ar.org.cfp6.tp4.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
