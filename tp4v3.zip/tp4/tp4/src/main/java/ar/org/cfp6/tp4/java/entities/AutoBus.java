package ar.org.cfp6.tp4.java.entities;

// subclase Autobus derivada de Vehiculo
public class AutoBus extends Vehiculo{

    // Esta (sub)clase hereda los campos de clase vehiculo

    // constructor de clase Autoclasico con parametros color marca modelo precio y Radio
    public AutoBus(String color, String marca, String modelo, double precio, Radio radio) {
        super(color, marca, modelo, precio, radio);
    }

    // constructor de clase Autoclasico sin precio y sin Radio
    public AutoBus(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }

    // constructor de clase Autoclasico con Radio y sin precio
    public AutoBus(String color, String marca, String modelo, Radio radio) {
        super(color, marca, modelo, radio);
    }

    // constructor de clase Autoclasico con precio y sin Radio
    public AutoBus(String color, String marca, String modelo, double precio) {
        super(color, marca, modelo, precio);
    }

    // sobreescritura de metodos cambiarRadio() y agregarRadio():

    // solo cambia radio en caso que el auto ya la tenga (valor distinto a null)
    @Override
    public void cambiarRadio(String marcaRadio, int potencia) {
        if (this.radio==null) {
            System.out.println("no hay radio para cambiar en el AutoBus.");
        }else {
            super.radio = new Radio(marcaRadio,potencia);
        }

    }
    // solo agrega radio en caso que el auto no la tenga (valor null)
    @Override
    public void agregarRadio(String marcaRadio, int potencia) {
       if (this.radio==null) {
        super.radio = new Radio(marcaRadio,potencia);
       } else {
        System.out.println("ya tiene radio el AutoBus.");
       } 
      
    }

    // Metodo ToString para mostrar datos:
    @Override
    public String toString() {
        return "AutoBus("+ super.toString() + ")";
    } 
}
 