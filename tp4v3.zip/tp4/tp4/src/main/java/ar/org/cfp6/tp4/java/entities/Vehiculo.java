package ar.org.cfp6.tp4.java.entities;

/*  Por motivos didacticos, no se usa lombok, entendiendo que en una implementacion practica
* la mencionada libreria permite un importante ahorro de codigo */

// clase super Vehiculo, padre de Autoclasico, AutoNuevo y AutoBus (colectivo o bondi)
public abstract class Vehiculo {

    // atributos de clase vehiculo
    protected String color;  
    protected String marca;
    protected String modelo;
    protected double precio;
    protected Radio radio;

    // Método constructor con  parametros color marca modelo precio y radio
    public Vehiculo(String color, String marca, String modelo, double precio, Radio radio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.radio = radio;
    }

    // Metodo constructor sobrecargado, sin precio y sin radio
    public Vehiculo(String color, String marca, String modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    // Metodo constructor sobrecargado con precio y sin radio
    public Vehiculo(String color, String marca, String modelo, double precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    // Metodo constructor sobrecargado sin precio y con radio
    public Vehiculo(String color, String marca, String modelo, Radio radio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.radio = radio;
    }

    // Métodos abstractos, que seran implementados en las subclases
    public abstract void cambiarRadio(String marcaRadio, int potencia);

    public abstract void agregarRadio(String marcaRadio, int potencia);

    /*  Metodos Getter de los atributos. */

    public String getColor() {
        return color;
    }



    public String getMarca() {
        return marca;
    }



    public String getModelo() {
        return modelo;
    }



    public double getPrecio() {
        return precio;
    }

    // Metodo toString sobreescrito
    @Override
    public String toString() {
        return "Vehiculo [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio + "]";
    }
    

}
