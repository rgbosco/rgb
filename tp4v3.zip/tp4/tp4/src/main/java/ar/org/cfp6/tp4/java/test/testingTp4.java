package ar.org.cfp6.tp4.java.test;

import ar.org.cfp6.tp4.java.entities.AutoBus;
import ar.org.cfp6.tp4.java.entities.AutoClasico;
import ar.org.cfp6.tp4.java.entities.AutoNuevo;
import ar.org.cfp6.tp4.java.entities.Radio;

public class testingTp4 {
    
    public static void main(String[] args) {

        // Se prueba con distintas instancias de las clases:

        System.out.println("===================================================");
        System.out.println("======================auto clasico======================");
        AutoClasico autoClasico = new AutoClasico("Rojo", "Ford", "Ka", 30000);
        autoClasico.agregarRadio("sharp", 20);
        System.out.println("auto clasico:" + autoClasico);
        System.out.println("===================================================");

        System.out.println("===================================================");
        System.out.println("====================autoBus 1=======================");
        AutoBus autoBus1 = new AutoBus("Blanco", "Fiat", "Uno", 20000);
        autoBus1.agregarRadio( "Sony" ,  20);
        System.out.println("auto bus 1: "+autoBus1);
        System.out.println("===================================================");

        System.out.println("====================autoBus 2=======================");
        System.out.println("===================================================");
        AutoBus autoBus2 = new AutoBus("negro", "Fiat", "palio");
        autoBus2.agregarRadio( "panasonic" ,  30);
        System.out.println("auto bus 2:" + autoBus2);
        System.out.println("===================================================");

        System.out.println("====================autoBus 3=======================");
        System.out.println("===================================================");
        AutoBus autoBus3 = new AutoBus("Blanco", "Fiat", "Uno", 20000);
        autoBus3.cambiarRadio( "Sony" ,  20);
        System.out.println("auto bus 3:" + autoBus3);
        System.out.println("================radio 1=============================");

        Radio radio1 = new Radio("tophouse" , 40);
        System.out.println("radio 1 :" + radio1);
        System.out.println("===================================================");

        System.out.println("================radio 2===========================");
        Radio radio2= new Radio("Spika",50);
        System.out.println(" marca de radio 2:" + radio2.getMarcaRadio());
        System.out.println(" potencia de radio 2:" + radio2.getPotencia());
        System.out.println("radio 2 :" + radio2);
        System.out.println("===================================================");

        System.out.println("==================auto nuevo 1======================");
        AutoNuevo autoNuevo = new AutoNuevo("Azul", "Toyota", "Corolla", 40000, radio1);
        autoNuevo.agregarRadio( "Sony" ,  20);
        System.out.println("auto nuevo 1:" + autoNuevo + radio1);
        System.out.println("===================================================");

        System.out.println("===================================================");
        System.out.println("==================auto nuevo 2======================");
        AutoNuevo autoNuevo2 = new AutoNuevo("GRis", "Ford", "Fiesta",radio1);
        autoNuevo2.agregarRadio( "Sony" ,  20);
        System.out.println("auto nuevo 2:" +autoNuevo2);
        System.out.println("===================================================");

        System.out.println("==================auto nuevo 3======================");
        System.out.println("===================================================");
        AutoNuevo autoNuevo3 = new AutoNuevo("plateado", "Fiat", "Cronos",radio2);
        System.out.println("auto nuevo 3: " + autoNuevo3.toString() + radio2.toString());
        System.out.println("===================================================");

        // Vehiculo vehiculo1 = new Vehiculo("Azul", "Toyota", "Corolla");
        // no se puede instanciar la clase vehiculo , es abstracta

    }

}
       