package ar.org.cfp6.tp4.java.entities;


// subclase AutoNuevo derivada de Vehiculo
public class AutoNuevo extends Vehiculo{
    
    // Esta (sub)clase hereda los campos de clase vehiculo

    // constructor de clase Autoclasico con parametros color marca modelo precio y Radio
    public AutoNuevo(String color, String marca, String modelo, double precio, Radio radio) {
        super(color, marca, modelo, precio, radio);
    }
    // constructor de clase AutoNuevo con parametros sin precio
    public AutoNuevo(String color, String marca, String modelo, Radio radio) {
        super(color, marca, modelo, radio);
    }


    // sobreescritura de metodos cambiarRadio() y agregarRadio():

    // solo cambia radio en caso que el auto ya la tenga (valor distinto a null)
    @Override
    public void cambiarRadio(String marcaRadio, int potencia) {
        if (this.radio==null) {
            System.out.println("no hay radio para cambiar en el Auto Clásico.");
        }else {
            super.radio = new Radio(marcaRadio,potencia);
        }
    }
        
    // como auto nuevo ya tiene radio no agrega una segunda radio
    @Override
    public void agregarRadio(String marcaRadio, int potencia) {
        System.out.println("No se puede agregar una radio adicional en un Auto Nuevo.");
       
    }

    // Metodo ToString para mostrar datos:
    @Override
    public String toString() {
        return "AutoNuevo("+ super.toString() + ")";
    } 
}
