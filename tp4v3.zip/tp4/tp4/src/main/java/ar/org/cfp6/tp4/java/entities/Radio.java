package ar.org.cfp6.tp4.java.entities;

// Clase Radio
public class Radio {

    // atributos de clase Radio
    protected String marcaRadio;  
    protected int potencia;   
    /*los fabricantes de radios especifican la potencia como un valor int
     aunque en realidad no sea tan asi.*/

    //constructor de la clase Radio
    public Radio(String marcaRadio, int potencia) {
        this.marcaRadio = marcaRadio;
        this.potencia = potencia;
    }

    // Metodos Getters para los atributos marcaRadio y potencia 
    public String getMarcaRadio() {
        return marcaRadio;
    }

    public int getPotencia() {
        return potencia;
    }

    // Metodo toString sobreescrito
    @Override
    public String toString() {
        return "Radio [marca de radio=" + marcaRadio + ", potencia=" + potencia + "]";
    }
    
}
