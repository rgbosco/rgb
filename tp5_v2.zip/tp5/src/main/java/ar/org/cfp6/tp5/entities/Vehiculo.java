package ar.org.cfp6.tp5.entities;

// se importa clase decimalformat, para poder formatear el double precio
import java.text.DecimalFormat;

//clase abstracta Vehiculo, no crea instancias, implementa interface comparable

public abstract class Vehiculo implements Comparable <Vehiculo> {
    // Atributos de clase Vehiculo, heredados en subclases Auto y Moto
    private String marca;
    private String modelo;
    private double precio;
    // Metodo constructor de Vehiculo
    public Vehiculo(String marca, String modelo, double precio) {
        this.marca= marca;
        this.modelo= modelo;
        this.precio= precio;
    }

    //metodos getter 

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

     // sobreescritura de compareTo, compara thisvehiculo con otrovehiculo
     @Override
    public int compareTo(Vehiculo otro) {
        DecimalFormat df = new DecimalFormat("000,000.00");
        String thisVehiculo = this.getMarca()+","+this.getModelo()+","+df.format(this.getPrecio());
        String otroVehiculo = otro.getMarca()+","+otro.getModelo()+","+df.format(otro.getPrecio());
        return thisVehiculo.compareTo(otroVehiculo);
    }

    

   

}
