package ar.org.cfp6.tp5.entities;

// se importa decimalformat para el formateo de double precio
import java.text.DecimalFormat;


// subclase Moto de clase Vehiculo
public class Moto extends Vehiculo {
    
    // clase Moto agrega el atributo cilindrada con tipo de dato entero
    private int cilindrada;

    // metodo constructor de moto
    public Moto(String marca, String modelo, double precio, int cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }
    
    // metodo getter para cilindrada
    public int getCilindrada() {
        return cilindrada;
    }

    // sobreescritura de metodo toString mostrando datos (con precio formateado)
    @Override
    public String toString() {
        // df es instancia de decimalformat
        DecimalFormat df = new DecimalFormat("###,##0.00");
        return "Marca: " + this.getMarca() + "// Modelo: " + this.getModelo() +
                " // Cilindrada: " + this.getCilindrada() + "c // Precio: $" + df.format(this.getPrecio());
    }

    
}