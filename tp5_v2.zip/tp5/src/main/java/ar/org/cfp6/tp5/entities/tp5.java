package ar.org.cfp6.tp5.entities;


// importacion de clases provistas por java, para formateo y operaciones con listas dinamicas
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

// clase principal tp5, contiene metodo main de entrada al proyecto
public class tp5 {

    // declaracion de variable de instancia vehiculos para un arreglo dnamico con objetos de tipo vehiculo
    private static List<Vehiculo> vehiculos = new ArrayList<>();

    // metodo main
    public static void main(String[] args) {

        // llamada a varios metodos, para mostrar por consola la lista pedida
        cargarLista();
        System.out.println(" ");
        mostrarLista();
        System.out.println("");
        System.out.println("========================");
        System.out.println("");
        mostrarMascaro();
        mostrarMasbarato();
        mostrarY();
        System.out.println("");
        System.out.println("========================");
        System.out.println("");
        ordenXPrecio();
        System.out.println("");
        System.out.println("=======================");
        System.out.println("");
        ordenNatural();
        System.out.println("");
        System.out.println("=======================");
        System.out.println("");
        
    }
    // metodo cargarlista, uso de add (agregar)
    private static void cargarLista() {
        vehiculos.add(new Auto("Peugeot", "206", 200000, 4));
        vehiculos.add(new Moto("Honda", "Titan", 60000, 125));
        vehiculos.add(new Auto("Peugeot", "208", 250000, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.5, 160));
    }
    // metodo mostrarlista, uso de foreach (para c/u)
    private static void mostrarLista() {
        vehiculos.forEach(System.out::println);
    }

    // metodos para mostrar vehiculo mas caro, mas barato  y que contenga "Y", usando stream
    private static void mostrarMascaro() {
        Vehiculo vehiculoCaro = vehiculos
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println("Vehiculo más caro: " + vehiculoCaro.getMarca() + " " +
                vehiculoCaro.getModelo());
    }

    private static void mostrarMasbarato() {
        Vehiculo vehiculoBarato = vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println("Vehiculo más barato: " + vehiculoBarato.getMarca() + " " +
                vehiculoBarato.getModelo());
    }

    private static void mostrarY() {
        DecimalFormat df = new DecimalFormat("###,##0.00");
        vehiculos
                .stream()
                .filter(o -> o.getModelo().toUpperCase().contains("Y"))
                .forEach(o -> System.out.println(
                        "Vehículo que contiene en el modelo la letra 'Y': " +
                                o.getMarca() + " " +
                                o.getModelo() + " $" +
                                df.format(o.getPrecio())));
    }

    // metodos para ordenar por precio y por orden natural (por marca en orden alfabetico primero, 
    // luego por orden numerico ascendente ,en modelo)

    private static void ordenXPrecio() {
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(o -> System.out.println(o.getMarca() + " " + o.getModelo()));
    }

    
    private static void ordenNatural() {
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        vehiculos
                .stream()
                .sorted()
                .forEach(System.out::println);
    }
}
