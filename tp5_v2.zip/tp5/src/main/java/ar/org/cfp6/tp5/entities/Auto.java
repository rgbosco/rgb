package ar.org.cfp6.tp5.entities;

// se importa decimalformat para el formateo de double precio
import java.text.DecimalFormat;

// subclase Auto de clase Vehiculo
public class Auto extends Vehiculo {

    // clase Auto agrega el atributo puertas con tipo de dato entero
    private int puertas;


    // Metodo constructor de auto
    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    // metodo getter para puertas
    public int getPuertas() {
        return puertas;
    }

    // sobreescritura de metodo toString mostrando datos (con precio formateado)
    @Override
    public String toString() {
        
        // df es instancia de decimalformat
        DecimalFormat df = new DecimalFormat("###,##0.00");
        return "Marca: " + this.getMarca() + " // Modelo: " + this.getModelo() +
                " // Puertas: " + this.getPuertas() + " // Precio: $" + df.format(this.getPrecio());
    }


    

    
}