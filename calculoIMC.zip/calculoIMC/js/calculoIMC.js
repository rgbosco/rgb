function calcularIMC(){
    peso=parseFloat(document.getElementById("peso").value)
    altura=parseFloat(document.getElementById("altura").value)
    campoimc= document.getElementById("imc")
    if (altura == 0){
        campoimc.setAttribute("value","Error, division por cero")
    }
    else{
        altura=altura/100
        imc= peso /(altura * altura)
        campoimc.setAttribute("value",imc.toFixed(1))
        
    }
    obtenerEstado(imc)
}

function obtenerEstado(imc) {
    estado =""
    campoestado= document.getElementById("estado")
    campoestado.classList.remove("text-secondary")
    

    if (imc < 15) {
        estado = "DELGADEZ MUY SEVERA, REQUIERE VISITA AL MEDICO"
        
    } 
    else if (imc >= 15 && imc <= 15.9) {
        estado = "DELGADEZ SEVERA, REQUIERE VISITA AL MEDICO"
        
    } 
    else if (imc > 15.9 && imc <= 18.4) {
        estado = "DELGADEZ, SE SUGIERE VISITA AL MEDICO"
    } 
    else if (imc > 18.4 && imc <= 24.9) {
        estado = "PESO NORMAL"
    }   
     else if (imc > 24.9 && imc <= 29.9) {
        estado = "SOBREPESO, SE SUGIERE VISITA AL MEDICO"
    }
    else if (imc > 29.9 && imc <= 34.9) {
        estado = "OBESIDAD, REQUIERE VISITA AL MEDICO"
        
    } 
    else if (imc >= 35 && imc <= 39.9) {
        estado = "OBESIDAD SEVERA, REQUIERE VISITA AL MEDICO"
        
    }
     else if (imc > 39.9) {
        estado = "OBESIDAD MORBIDA, REQUIERE VISITA AL MEDICO"
        
    } 
    
    campoestado.className = "form-control-plaintext text-primary" + " bg-primary-subtle" ;
    campoestado.setAttribute("value",estado)
}

function resetear(){
    document.getElementById("peso").value="0" 
    document.getElementById("altura").value= "0"
    document.getElementById("imc").setAttribute("value",0) 
    document.getElementById("estado").setAttribute("value","")
}